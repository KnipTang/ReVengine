The 'codegen' tool can be used to parse SoLoud headers and generate the
soloud_codegen.py file.

This file can then be used to generate various "glue" code for non-c 
environments.
